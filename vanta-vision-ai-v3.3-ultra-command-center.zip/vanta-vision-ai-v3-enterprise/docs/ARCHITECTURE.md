# Architecture
Camera/RTSP → edge decode → detection/tracking → Re-ID embedding → Qdrant/Milvus → event/spatial engine → WHIP/MediaMTX → WHEP browser + WebRTC DataChannel metadata → WebGL HUD. Prometheus observes the control plane; Grafana visualizes fleet health. Edge SQLite buffers events while offline and flushes deltas after reconnect.
