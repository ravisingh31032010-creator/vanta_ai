# API
GET `/health` — health check.
GET/POST/DELETE `/api/v1/streams` — stream registry.
GET `/api/v1/models` — model/runtime capabilities.
POST `/api/v1/analytics/geofence/check` — point-in-polygon check.
GET `/api/v1/analytics/summary` — analytics summary.
GET `/metrics` — Prometheus metrics.
WS `/ws/telemetry/{stream_id}` — lightweight telemetry channel; production deployments should prefer WebRTC DataChannels for frame-synchronous metadata.
