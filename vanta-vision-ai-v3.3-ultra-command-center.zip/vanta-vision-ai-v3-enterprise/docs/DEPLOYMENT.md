# Deployment
For NVIDIA edge nodes, install a compatible NVIDIA driver/CUDA/TensorRT stack and replace the ingestion/inference adapters with the target-specific GStreamer + NVDEC/NVENC + TensorRT implementation. For production, put MediaMTX behind TLS, set a strong JWT secret, use PostgreSQL/TimescaleDB, enable authenticated Qdrant/Milvus, and lock down CORS/network policies.
