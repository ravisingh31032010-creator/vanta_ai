# VANTA Vision AI v3 — Next-Level Ultra-Enterprise

Edge-cloud computer-vision platform foundation for multi-camera Re-ID, WebRTC/WHIP/WHEP, GPU HUD rendering, Prometheus/Grafana observability, and resilient edge-to-cloud inference.

## What is implemented
- FastAPI control plane with stream/analytics/model endpoints.
- Cross-camera Re-ID pipeline interface with deterministic demo embeddings and optional Torch/ONNX adapters.
- Qdrant vector-store adapter with an in-memory fallback for local development.
- WebRTC session/control layer with MediaMTX WHIP/WHEP integration points.
- React + Three.js WebGL HUD capable of rendering batched target boxes/trails/geofences.
- Prometheus metrics for FPS, inference latency, active tracks and GPU memory.
- Edge SQLite offline queue with retry/delta synchronization.
- Cloud VLM reasoner adapter using an OpenAI-compatible HTTP endpoint; disabled by default.
- Docker Compose stack for API, worker, Redis, Qdrant, MediaMTX, Prometheus and Grafana.
- Tests for spatial logic, Re-ID matching, offline queue and API health.

## Production integrations
Hardware-specific TensorRT/NVDEC/NVENC, Jetson pipelines, Triton, full FastReID/OSNet weights and a production VLM endpoint require deployment-specific models/drivers. The code keeps these behind adapters rather than pretending a CPU-only environment is a GPU production cluster.

## Quick start
```bash
cd backend
python -m venv .venv
# activate the venv
pip install -r requirements.txt
uvicorn app.main:app --reload --port 8000
```
Frontend:
```bash
cd frontend
npm install
npm run dev
```

Docker:
```bash
docker compose -f docker/docker-compose.yml up --build
```

Default local URLs: API `http://localhost:8000`, Qdrant `http://localhost:6333`, MediaMTX `http://localhost:9997`, Prometheus `http://localhost:9090`, Grafana `http://localhost:3000`.


## Frontend Command Center v3.2

The frontend has been upgraded into a cohesive VANTA cyberpunk command center:
- Multi-stream 2x2 live matrix with focus mode and active-camera switching.
- WebRTC/WHEP player per camera with simulation fallback when no WHEP endpoint is configured.
- Three.js WebGL HUD layer with target boxes, geofence rendering and animated scan beam.
- Interactive ROI/geofence drawing with FastAPI sync at `/api/v1/streams/{stream_id}/geofence`.
- Live telemetry rail for FPS, tracks, inference latency and GPU utilization.
- Cross-camera Re-ID and VLM alert event panels.
- Mobile-responsive layout and compact tactical controls.

### Frontend environment
Set `VITE_API_BASE`, `VITE_WS_BASE`, and `VITE_WHEP_URL`. `VITE_WHEP_URL` may contain `{stream_id}` to address different camera endpoints.

## v3.3 Ultra Command Center UI
This release adds a cohesive flagship dashboard layer: AI command palette (Ctrl/Cmd+K), Digital Twin spatial view, mission mode, camera/zone/target search, incident timeline with replay trigger, target relationship graph, active-camera focus, enhanced HUD status chips, and responsive control-room styling. These are frontend orchestration/demo capabilities and connect to the existing backend integration seams.
