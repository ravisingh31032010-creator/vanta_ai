import numpy as np
from app.engine.reid import ReIDEngine
def test_embedding_shape():
 e=ReIDEngine(); v=e.embed(np.zeros((8,8,3),dtype=np.uint8)); assert v.shape==(512,)
