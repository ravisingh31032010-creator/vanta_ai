from app.engine.spatial import point_in_polygon
def test_polygon(): assert point_in_polygon(1,1,[(0,0),(2,0),(2,2),(0,2)])
