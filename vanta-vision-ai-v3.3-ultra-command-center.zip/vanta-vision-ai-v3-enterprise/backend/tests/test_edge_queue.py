from app.engine.edge_sync import EdgeQueue
def test_queue(tmp_path):
 q=EdgeQueue(str(tmp_path/'q.db')); q.enqueue({'x':1}); assert q.size()==1
