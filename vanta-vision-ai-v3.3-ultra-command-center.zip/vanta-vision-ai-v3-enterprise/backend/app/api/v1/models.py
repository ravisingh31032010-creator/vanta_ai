from fastapi import APIRouter
from app.engine.inference import InferenceEngine
router=APIRouter(prefix='/models',tags=['models'])
@router.get('')
async def models(): return {'inference':InferenceEngine().info(),'reid':{'dimensions':[512,2048],'stores':['qdrant','milvus']},'vlm':{'edge_triggered':True}}
