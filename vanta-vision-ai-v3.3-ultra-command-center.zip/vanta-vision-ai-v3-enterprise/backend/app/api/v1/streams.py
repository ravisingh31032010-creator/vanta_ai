from fastapi import APIRouter, HTTPException
from app.schemas.common import StreamIn, StreamOut
router=APIRouter(prefix='/streams',tags=['streams']); STREAMS={
  'CAM-01': {'stream_id':'CAM-01','url':'','enabled':True,'health':'simulated'},
  'CAM-02': {'stream_id':'CAM-02','url':'','enabled':True,'health':'simulated'},
  'CAM-03': {'stream_id':'CAM-03','url':'','enabled':True,'health':'simulated'},
  'CAM-04': {'stream_id':'CAM-04','url':'','enabled':True,'health':'simulated'},
}
GEOFENCES={}
@router.get('',response_model=list[StreamOut])
async def list_streams(): return [StreamOut(**v) for v in STREAMS.values()]
@router.post('',response_model=StreamOut)
async def add_stream(s:StreamIn):
    STREAMS[s.stream_id]={**s.model_dump(),'health':'configured'}; return StreamOut(**STREAMS[s.stream_id])
@router.delete('/{stream_id}')
async def delete_stream(stream_id:str):
    if stream_id not in STREAMS: raise HTTPException(404,'stream not found')
    del STREAMS[stream_id]; return {'ok':True}

@router.post('/{stream_id}/geofence')
async def set_geofence(stream_id:str, payload:dict):
    if stream_id not in STREAMS: raise HTTPException(404,'stream not found')
    points=payload.get('points',[])
    if not isinstance(points,list) or len(points)<3: raise HTTPException(422,'at least 3 points required')
    GEOFENCES[stream_id]={'stream_id':stream_id,'points':points,'vertices':len(points)}
    return {'ok':True, **GEOFENCES[stream_id]}

@router.get('/{stream_id}/geofence')
async def get_geofence(stream_id:str):
    if stream_id not in STREAMS: raise HTTPException(404,'stream not found')
    return GEOFENCES.get(stream_id, {'stream_id':stream_id,'points':[],'vertices':0})
