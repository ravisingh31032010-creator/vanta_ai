from fastapi import APIRouter
from app.engine.spatial import point_in_polygon
router=APIRouter(prefix='/analytics',tags=['analytics'])
@router.post('/geofence/check')
async def geofence_check(x:float,y:float,polygon:list[tuple[float,float]]): return {'inside':point_in_polygon(x,y,polygon)}
@router.get('/summary')
async def summary(): return {'active_tracks':0,'fps':0,'alerts':0}
