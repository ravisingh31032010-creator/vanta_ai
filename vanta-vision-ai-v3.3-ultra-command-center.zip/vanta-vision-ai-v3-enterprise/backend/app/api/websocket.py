from fastapi import APIRouter, WebSocket
import time
router=APIRouter()
@router.websocket('/ws/telemetry/{stream_id}')
async def telemetry(ws:WebSocket,stream_id:str):
    await ws.accept()
    while True:
        await ws.send_json({'stream_id':stream_id,'timestamp_ns':time.time_ns(),'fps':0,'tracks':0})
        try: await ws.receive_text()
        except Exception: break
