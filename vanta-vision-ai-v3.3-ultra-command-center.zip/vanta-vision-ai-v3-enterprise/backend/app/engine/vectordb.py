from app.core.config import settings
class VectorStore:
    def __init__(self): self.client=None; self.memory=[]
    async def connect(self):
        try:
            from qdrant_client import AsyncQdrantClient
            from qdrant_client.models import Distance, VectorParams
            self.client=AsyncQdrantClient(url=settings.qdrant_url)
            cols=await self.client.get_collections()
            if settings.qdrant_collection not in [c.name for c in cols.collections]:
                await self.client.create_collection(settings.qdrant_collection, vectors_config=VectorParams(size=512,distance=Distance.COSINE))
        except Exception: self.client=None
    async def upsert(self, point_id, vector, payload):
        if self.client:
            from qdrant_client.models import PointStruct
            await self.client.upsert(settings.qdrant_collection,[PointStruct(id=point_id,vector=vector,payload=payload)])
        else: self.memory.append((point_id,vector,payload))
    async def search(self, vector, limit=5):
        if self.client: return await self.client.search(settings.qdrant_collection, query_vector=vector, limit=limit)
        import numpy as np
        return sorted([{'id':i,'score':float(np.dot(vector,v)/(np.linalg.norm(vector)*np.linalg.norm(v)+1e-8)),'payload':p} for i,v,p in self.memory], key=lambda x:x['score'], reverse=True)[:limit]
