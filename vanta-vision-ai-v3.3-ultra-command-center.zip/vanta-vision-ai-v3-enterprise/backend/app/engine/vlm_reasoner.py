import base64, httpx
from app.core.config import settings
class VLMReasoner:
    async def reason(self, image_bytes:bytes, prompt:str):
        if not settings.vlm_enabled: return {'enabled':False,'reason':'VLM is disabled'}
        b64=base64.b64encode(image_bytes).decode()
        body={'model':settings.vlm_model,'messages':[{'role':'user','content':[{'type':'text','text':prompt},{'type':'image_url','image_url':{'url':f'data:image/jpeg;base64,{b64}'}}]}]}
        async with httpx.AsyncClient(timeout=30) as c:
            r=await c.post(settings.vlm_url,json=body); r.raise_for_status(); return r.json()
