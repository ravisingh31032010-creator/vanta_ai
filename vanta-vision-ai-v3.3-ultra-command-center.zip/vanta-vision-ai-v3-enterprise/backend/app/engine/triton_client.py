import httpx
class TritonAdapter:
    def __init__(self,base_url='http://triton:8000'): self.base_url=base_url.rstrip('/')
    async def health(self):
        async with httpx.AsyncClient(timeout=2) as c:
            r=await c.get(self.base_url+'/v2/health/ready'); return r.is_success
