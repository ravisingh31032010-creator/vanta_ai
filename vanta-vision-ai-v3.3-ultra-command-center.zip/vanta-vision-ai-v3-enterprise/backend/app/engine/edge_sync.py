import sqlite3, json, time, httpx
class EdgeQueue:
    def __init__(self,path='edge_queue.db'):
        self.db=sqlite3.connect(path, check_same_thread=False); self.db.execute('CREATE TABLE IF NOT EXISTS queue(id INTEGER PRIMARY KEY, payload TEXT, created REAL)'); self.db.commit()
    def enqueue(self,payload): self.db.execute('INSERT INTO queue(payload,created) VALUES(?,?)',(json.dumps(payload),time.time())); self.db.commit()
    def size(self): return self.db.execute('SELECT COUNT(*) FROM queue').fetchone()[0]
    async def flush(self,url,batch=100):
        rows=self.db.execute('SELECT id,payload FROM queue ORDER BY id LIMIT ?', (batch,)).fetchall()
        if not rows:return 0
        async with httpx.AsyncClient(timeout=10) as c:
            r=await c.post(url,json={'events':[json.loads(p) for _,p in rows]}); r.raise_for_status()
        self.db.executemany('DELETE FROM queue WHERE id=?',[(i,) for i,_ in rows]); self.db.commit(); return len(rows)
