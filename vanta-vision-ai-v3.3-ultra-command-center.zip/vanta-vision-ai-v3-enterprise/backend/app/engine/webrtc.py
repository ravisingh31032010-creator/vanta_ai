from dataclasses import dataclass
from app.core.config import settings
@dataclass
class WebRTCSession:
    stream_id:str; whep_url:str; whip_url:str
class WebRTCEngine:
    def session(self, stream_id:str)->WebRTCSession:
        base=settings.webrtc_public_base.rstrip('/')
        return WebRTCSession(stream_id, f'{base}/{stream_id}/whep', f'{base}/{stream_id}/whip')
