from dataclasses import dataclass
import hashlib, numpy as np
@dataclass
class ReIDMatch:
    target_id:str; score:float; camera_id:str; timestamp_ns:int
class ReIDEngine:
    def __init__(self, dim:int=512, threshold:float=.72): self.dim=dim; self.threshold=threshold
    def embed(self, crop:np.ndarray)->np.ndarray:
        # Deterministic baseline embedding for integration tests; replace with OSNet/FastReID/CLIP in production.
        raw=np.ascontiguousarray(crop).tobytes(); seed=int.from_bytes(hashlib.sha256(raw).digest()[:8],'big')
        rng=np.random.default_rng(seed); v=rng.normal(size=self.dim).astype('float32'); return v/np.linalg.norm(v)
    def cosine(self,a,b): return float(np.dot(a,b)/(np.linalg.norm(a)*np.linalg.norm(b)+1e-8))
    def match(self, query, candidates, now_ns:int, min_gap_ns:int=5_000_000_000, max_gap_ns:int=60_000_000_000):
        best=None
        for c in candidates:
            gap=now_ns-c.timestamp_ns
            if c.camera_id==query.camera_id or gap<min_gap_ns or gap>max_gap_ns: continue
            score=self.cosine(query.vector,c.vector)
            if score>=self.threshold and (best is None or score>best.score): best=ReIDMatch(c.target_id,score,c.camera_id,c.timestamp_ns)
        return best
