from dataclasses import dataclass
@dataclass
class Track: id:int; bbox:tuple[float,float,float,float]; score:float
class ByteTrackCompatible:
    def __init__(self): self.next_id=1; self.tracks=[]
    def update(self,detections):
        # Lightweight IoU tracker interface. Replace with ByteTrack/BoT-SORT for production GPU deployments.
        out=[]
        for d in detections:
            out.append(Track(self.next_id,d.bbox,d.confidence)); self.next_id+=1
        self.tracks=out; return out
