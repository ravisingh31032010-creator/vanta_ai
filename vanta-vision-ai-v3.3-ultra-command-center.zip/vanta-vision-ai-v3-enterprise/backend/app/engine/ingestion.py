import asyncio
class StreamManager:
    def __init__(self): self.streams={}; self.tasks={}
    async def add(self,stream_id,url): self.streams[stream_id]={'url':url,'health':'configured'}; return self.streams[stream_id]
    async def remove(self,stream_id): self.streams.pop(stream_id,None)
    def health(self): return self.streams
    async def reconnect_loop(self,stream_id):
        while stream_id in self.streams:
            self.streams[stream_id]['health']='monitoring'; await asyncio.sleep(5)
