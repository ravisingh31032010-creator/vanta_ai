def point_in_polygon(x,y,poly):
    inside=False
    for i in range(len(poly)):
        x1,y1=poly[i]; x2,y2=poly[(i+1)%len(poly)]
        if ((y1>y)!=(y2>y)) and x < (x2-x1)*(y-y1)/(y2-y1+1e-12)+x1: inside=not inside
    return inside
def dwell_seconds(first_ns, now_ns): return max(0,now_ns-first_ns)/1e9
