class InferenceEngine:
    def __init__(self, backend='onnxruntime'): self.backend=backend
    async def detect(self, frame): return []
    def info(self): return {'backend':self.backend,'dynamic_batch':True,'batch_range':[1,32]}
