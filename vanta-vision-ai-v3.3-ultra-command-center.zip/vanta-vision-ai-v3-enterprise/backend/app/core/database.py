from sqlalchemy.ext.asyncio import create_async_engine, async_sessionmaker, AsyncSession
from sqlalchemy.orm import DeclarativeBase
from app.core.config import settings
class Base(DeclarativeBase): pass
engine=create_async_engine(settings.database_url, echo=False)
SessionLocal=async_sessionmaker(engine, expire_on_commit=False, class_=AsyncSession)
async def init_db():
    from app.models.events import VisionEvent
    async with engine.begin() as conn: await conn.run_sync(Base.metadata.create_all)
