from pydantic_settings import BaseSettings, SettingsConfigDict
class Settings(BaseSettings):
    env: str='development'; database_url: str='sqlite+aiosqlite:///./vanta.db'; redis_url: str='redis://localhost:6379/0'
    qdrant_url: str='http://localhost:6333'; qdrant_collection: str='vanta_reid'; mediamtx_url: str='http://localhost:9997'
    webrtc_public_base: str='http://localhost:8889'; jwt_secret: str='change-this-in-production'; vlm_enabled: bool=False
    vlm_url: str='http://localhost:11434/v1/chat/completions'; vlm_model: str='vision-model'; cors_origins: str='http://localhost:5173'
    model_config=SettingsConfigDict(env_file='.env', extra='ignore')
settings=Settings()
