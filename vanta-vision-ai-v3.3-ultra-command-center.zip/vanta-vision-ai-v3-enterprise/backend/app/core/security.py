from datetime import datetime, timedelta, timezone
import jwt
from app.core.config import settings
def create_access_token(subject:str, role:str='viewer', minutes:int=60):
    now=datetime.now(timezone.utc); return jwt.encode({'sub':subject,'role':role,'iat':now,'exp':now+timedelta(minutes=minutes)}, settings.jwt_secret, algorithm='HS256')
def decode_access_token(token:str): return jwt.decode(token, settings.jwt_secret, algorithms=['HS256'])
