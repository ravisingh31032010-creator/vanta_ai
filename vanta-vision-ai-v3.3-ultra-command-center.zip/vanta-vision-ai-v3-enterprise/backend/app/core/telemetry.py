from prometheus_client import Counter, Gauge, Histogram
STREAM_FPS=Gauge('vanta_stream_fps','Current FPS per camera feed',['stream_id'])
INFERENCE_LATENCY=Histogram('vanta_inference_latency_seconds','Inference latency',['stage'])
GPU_MEMORY=Gauge('vanta_gpu_memory_used_bytes','GPU VRAM usage')
ACTIVE_TRACKS=Gauge('vanta_active_tracks_count','Active tracks',['stream_id'])
ALERTS=Counter('vanta_alerts_total','Generated alerts',['type'])
def gpu_memory_bytes():
    try:
        import pynvml; pynvml.nvmlInit(); return pynvml.nvmlDeviceGetMemoryInfo(pynvml.nvmlDeviceGetHandleByIndex(0)).used
    except Exception: return 0
