from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from prometheus_client import make_asgi_app
from app.core.config import settings
from app.core.database import init_db
from app.api.v1.streams import router as streams
from app.api.v1.analytics import router as analytics
from app.api.v1.models import router as models
from app.api.websocket import router as ws
app=FastAPI(title='VANTA Vision AI v3 Enterprise',version='3.1.0')
app.add_middleware(CORSMiddleware,allow_origins=[x.strip() for x in settings.cors_origins.split(',')],allow_credentials=True,allow_methods=['*'],allow_headers=['*'])
app.include_router(streams,prefix='/api/v1'); app.include_router(analytics,prefix='/api/v1'); app.include_router(models,prefix='/api/v1'); app.include_router(ws)
app.mount('/metrics',make_asgi_app())
@app.on_event('startup')
async def startup(): await init_db()
@app.get('/health')
async def health(): return {'status':'ok','version':app.version}
