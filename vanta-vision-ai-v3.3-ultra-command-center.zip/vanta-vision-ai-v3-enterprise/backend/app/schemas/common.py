from pydantic import BaseModel, Field
class BBox(BaseModel): x1:float; y1:float; x2:float; y2:float
class Detection(BaseModel): label:str; confidence:float=Field(ge=0,le=1); bbox:BBox; track_id:str|None=None
class StreamIn(BaseModel): stream_id:str; url:str; enabled:bool=True
class StreamOut(StreamIn): health:str='unknown'
class Telemetry(BaseModel): stream_id:str; timestamp_ns:int; fps:float; inference_ms:float; tracks:int; detections:list[Detection]=[]
