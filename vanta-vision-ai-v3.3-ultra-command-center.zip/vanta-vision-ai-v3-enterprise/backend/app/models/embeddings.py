from dataclasses import dataclass
from datetime import datetime
@dataclass
class EmbeddingRecord:
    target_id:str; camera_id:str; vector:list[float]; timestamp:datetime; quality:float=1.0
