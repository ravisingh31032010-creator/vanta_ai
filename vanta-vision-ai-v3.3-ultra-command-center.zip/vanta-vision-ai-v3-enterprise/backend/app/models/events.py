from datetime import datetime
from sqlalchemy import String, Float, DateTime, Integer
from sqlalchemy.orm import Mapped, mapped_column
from app.core.database import Base
class VisionEvent(Base):
    __tablename__='vision_events'
    id: Mapped[int]=mapped_column(Integer, primary_key=True)
    tenant_id: Mapped[str]=mapped_column(String(100), index=True)
    stream_id: Mapped[str]=mapped_column(String(100), index=True)
    label: Mapped[str]=mapped_column(String(100))
    confidence: Mapped[float]=mapped_column(Float)
    track_id: Mapped[str|None]=mapped_column(String(100), nullable=True)
    created_at: Mapped[datetime]=mapped_column(DateTime, default=datetime.utcnow)
