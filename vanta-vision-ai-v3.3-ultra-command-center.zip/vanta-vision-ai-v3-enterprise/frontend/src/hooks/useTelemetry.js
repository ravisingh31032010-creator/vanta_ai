import {useEffect,useRef,useState} from 'react';
export default function useTelemetry(streamId){
 const [telemetry,setTelemetry]=useState({fps:0,tracks:0,inference_ms:0,gpu:0}); const [alerts,setAlerts]=useState([]); const ws=useRef(null);
 useEffect(()=>{ if(!streamId)return; const base=import.meta.env.VITE_WS_BASE || 'ws://localhost:8000'; let stopped=false;
   try{ ws.current=new WebSocket(`${base}/ws/telemetry/${encodeURIComponent(streamId)}`); ws.current.onmessage=e=>{try{const d=JSON.parse(e.data);setTelemetry({fps:d.fps||0,tracks:d.tracks||0,inference_ms:d.inference_ms||0,gpu:d.gpu||0}); if(d.alert)setAlerts(a=>[{...d.alert,id:crypto.randomUUID?.()||Date.now()},...a].slice(0,8));}catch{}}; }catch{}
   const demo=setInterval(()=>{if(!stopped)setTelemetry(t=>({fps:t.fps?Math.min(60,t.fps+(Math.random()-.5)*2):58+Math.random()*2,tracks:Math.max(0,Math.round(6+Math.random()*8)),inference_ms:7+Math.random()*5,gpu:34+Math.random()*12}));},1000);
   return()=>{stopped=true;clearInterval(demo);ws.current?.close()};
 },[streamId]); return {telemetry,alerts};
}
