export const vertexShader=`attribute vec3 position; void main(){gl_Position=vec4(position,1.0);}`;
export const fragmentShader=`precision mediump float; uniform float uTime; void main(){float scan=0.5+0.5*sin((gl_FragCoord.y+uTime*80.0)*0.08); gl_FragColor=vec4(vec3(scan),0.12);}`;
