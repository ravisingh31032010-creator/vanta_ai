import React,{useEffect,useRef,useState} from 'react';
export default function WebRTCPlayer({whepUrl,streamId,muted=true}){
 const video=useRef(null); const [status,setStatus]=useState(whepUrl?'CONNECTING':'SIMULATION');
 useEffect(()=>{let pc,dead=false;if(!whepUrl){setStatus('SIMULATION');return()=>{};}
  (async()=>{try{pc=new RTCPeerConnection({iceServers:[]});pc.onconnectionstatechange=()=>setStatus(pc.connectionState.toUpperCase());pc.ontrack=e=>{if(video.current)video.current.srcObject=e.streams[0]};pc.addTransceiver('video',{direction:'recvonly'});const offer=await pc.createOffer();await pc.setLocalDescription(offer);const r=await fetch(whepUrl,{method:'POST',headers:{'Content-Type':'application/sdp','Accept':'application/sdp'},body:offer.sdp});if(!r.ok)throw new Error(`WHEP ${r.status}`);const answer=await r.text();if(!dead)await pc.setRemoteDescription({type:'answer',sdp:answer});}catch(e){if(!dead)setStatus('SIGNAL LOST');}}
  )();return()=>{dead=true;pc?.close();if(video.current)video.current.srcObject=null}},[whepUrl,streamId]);
 return <div className="webrtc-shell"><video ref={video} autoPlay playsInline muted={muted}/><div className="stream-status"><i/> {status}</div>{!whepUrl&&<div className="sim-feed"><span>{streamId}</span><b>LIVE SIMULATION</b><em>WHEP endpoint not configured</em></div>}</div>
}
